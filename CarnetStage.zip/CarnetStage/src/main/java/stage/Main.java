package stage;

import dao.Connexion;
import dao.HistoriqueDAO;

public class Main {

	public static void main(String[] args) {


		Connexion.getInstance();
		System.out.println(HistoriqueDAO.getInstance().read(4));

		//Historique historique=HistoriqueDAO.getInstance().read(1);
		//System.out.println(historique);
	}

}
